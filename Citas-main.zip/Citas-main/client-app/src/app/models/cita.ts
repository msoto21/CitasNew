export interface Cita {
  id: string;
  fechaHoraInicio: string;
  fechaHoraFin: string;
  cliente: string;
  titulo: string;
  descripcion: string;
  tratamientos: string;
  nota: string;
}